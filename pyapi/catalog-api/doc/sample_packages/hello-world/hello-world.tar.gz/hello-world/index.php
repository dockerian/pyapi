<html>
 <head>
  <title>Hello World - PHP Test</title>
 </head>
 <body>
  <div>
    <?php
      echo "\n Hello World \n";
    ?>
    <img src="hello-world.png" style="vertical-align:middle;"/>
  </div>
  <?php
    //phpinfo();
  ?>
 </body>
<html>
