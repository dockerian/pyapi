# Node.js ENVIRONMENT

A simple demo that prints the server's environment variables.

## Local development

    node server.js

## Deploying to Helion

    helion push -n --reset --as 'node-env'
